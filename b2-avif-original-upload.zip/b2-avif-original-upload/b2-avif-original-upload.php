
<?php
/**
 * Plugin Name: B2 AVIF Original Upload Support
 * Description: WordPress 6.9.4 / B2 PRO 经典编辑器 AVIF 原图上传支持。
 * Version: 2.0.0
 * Author: 码铃薯
 * Author URI: https://www.tudoucode.cn/
 * Copyright: 码铃薯
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * 1. 注册 AVIF MIME 类型
 */
add_filter('upload_mimes', function ($mimes) {
    $mimes['avif'] = 'image/avif';
    return $mimes;
}, PHP_INT_MAX);


/**
 * 2. 判断是否为 AVIF
 */
function b2_avif_is_original($file) {
    return is_string($file)
        && $file !== ''
        && strtolower(pathinfo($file, PATHINFO_EXTENSION)) === 'avif';
}


/**
 * 3. 关键修复：经典媒体上传器
 *
 * WordPress 传统 Plupload 上传器。
 */
add_filter('plupload_init', function ($settings) {

    // 不再因为服务器不支持 AVIF 解码而阻止上传
    $settings['avif_upload_error'] = false;

    return $settings;

}, PHP_INT_MAX);


/**
 * 4. 关键修复：新版媒体库弹窗上传器
 *
 * WordPress 6.9.4 使用的默认 Plupload 配置。
 */
add_filter('plupload_default_settings', function ($settings) {

    $settings['avif_upload_error'] = false;

    return $settings;

}, PHP_INT_MAX);


/**
 * 5. 允许 AVIF 绕过服务器图片编辑器支持检查
 *
 * 不影响其他图片格式。
 */
add_filter(
    'wp_prevent_unsupported_mime_type_uploads',
    function ($prevent, $mime_type) {

        if (strtolower((string) $mime_type) === 'image/avif') {
            return false;
        }

        return $prevent;

    },
    PHP_INT_MAX,
    2
);


/**
 * 6. AVIF 禁止生成 scaled 大图
 */
add_filter(
    'big_image_size_threshold',
    function ($threshold, $imagesize, $file, $attachment_id) {

        if (b2_avif_is_original($file)) {
            return false;
        }

        return $threshold;

    },
    PHP_INT_MAX,
    4
);


/**
 * 7. AVIF 禁止生成所有中间尺寸
 *
 * 包括 thumbnail、medium、large 等。
 */
add_filter(
    'intermediate_image_sizes_advanced',
    function ($sizes, $image_meta, $attachment_id) {

        $file = get_attached_file($attachment_id);

        if (b2_avif_is_original($file)) {
            return array();
        }

        return $sizes;

    },
    PHP_INT_MAX,
    3
);


/**
 * 8. AVIF 不生成缺失尺寸
 */
add_filter(
    'fallback_intermediate_image_sizes',
    function ($sizes) {

        $attachment_id = isset($_REQUEST['attachment_id'])
            ? absint($_REQUEST['attachment_id'])
            : 0;

        if (
            $attachment_id &&
            b2_avif_is_original(get_attached_file($attachment_id))
        ) {
            return array();
        }

        return $sizes;

    },
    PHP_INT_MAX
);
